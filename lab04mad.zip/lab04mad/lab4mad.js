// Task1 fictorial with recurrsion
// function factorial(n) {
//     if (n === 0) {
//       return 1;
//     } else {
//       return n * factorial(n - 1);
//     }
// }
// console.log(factorial(4))

// Task2 isFibonacci with recurrsion

function isFibonacci(num, a = 0, b = 1) {
    if (num === a || num === b) {
      return "The number occurs in Fibonacci";
    } else if (b > num) {
      return "The number does not occurs in Fibonacci";
    } else {
      return isFibonacci(num, b, a + b);
    }
  }
  console.log(isFibonacci(10))